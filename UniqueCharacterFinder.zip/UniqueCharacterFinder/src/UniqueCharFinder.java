import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class UniqueCharFinder {

	public static void main(String [] a)
	{
		System.out.println("Enter a string - ");
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
        try {
        	
			String  s = br.readLine();
			System.out.println("Entered string - " + s);
			char uc= findUniqueChar(s);
			if(uc=='\u0000' )
				System.out.println("No Unique Character Found");
			else
				System.out.println("Unique Charcter - " + uc);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Failed to read input string");
			e.printStackTrace();
		}
	}
	
	
	/*
	 *  This function returns the unique character in the parameter string.
	 */
	public static char findUniqueChar(String s)
	{
		
		char allChars[] = s.toCharArray();
		char unique='\u0000' ;
	
		for(int i = 0 ; i<allChars.length;i++)
		{
			if(validate(allChars, allChars[i]))
			{
				unique = allChars[i];
				break; // break once we find our first unique character. " Saves iterations ! "
			}
		}
		return unique;
	}
	
	/*
	 *  This funtion validates if the character is unique in the given char array or not. 
	 */
	public static boolean validate(char [] ac , char c)
	{
		
		int count = 0;
		for(int i=0;i<ac.length;i++)
		{
			if(ac[i]==c)
				count++;
		}
		if(count==1)
			return true;
		else
			return false;
	}
	
	
	

	

}
